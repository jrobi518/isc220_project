package edu.oswego.isc_220_weatherapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    TextView newCity, citySelection, weatherCondition, temperature, pressure, windSpeed, cloudCover;
    String city = "Syracuse, US";
    String OPEN_WEATHER_MAP_API = "6801b5ec1cc5e85cab909ea7aca34700";

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            newCity = (TextView) findViewById(R.id.new_City);
            citySelection = (TextView) findViewById(R.id.city_selected);
            weatherCondition = (TextView) findViewById(R.id.weather);
            temperature = (TextView) findViewById(R.id.temperature);
            pressure = (TextView) findViewById(R.id.pressure);
            windSpeed = (TextView) findViewById(R.id.wind);
            cloudCover = (TextView) findViewById(R.id.clouds);
            taskLoadUp(city);

            newCity.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
                    alertDialog.setTitle("Enter New City");
                    final EditText input = new EditText(MainActivity.this);
                    input.setText(city);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.MATCH_PARENT);
                    input.setLayoutParams(lp);
                    alertDialog.setView(input);
                    alertDialog.setPositiveButton("Find The Weather",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    city = input.getText().toString();
                                    taskLoadUp(city);
                                }
                            });
                    alertDialog.setNegativeButton("Go Back",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();
                                }
                            });
                    alertDialog.show();
                }
            });
        }

        public void taskLoadUp(String query) {
            if (connectionFunction.networkAvailability(getApplicationContext())) {
                DownloadWeather task = new DownloadWeather();
                task.execute(query);
            } else {
                Toast.makeText(getApplicationContext(), "Unable To Connect To OpenWeather", Toast.LENGTH_LONG).show();
            }
        }

        class DownloadWeather extends AsyncTask < String, Void, String > {
            @Override
            protected String doInBackground(String...args) {
                String xml = connectionFunction.jsonGet("http://api.openweathermap.org/data/2.5/weather?q=" + args[0] + "&units=imperial&appid=" + OPEN_WEATHER_MAP_API);
                return xml;
            }
            @Override
            protected void onPostExecute(String xml) {
                try {
                    JSONObject json = new JSONObject(xml);
                    if (json != null) {
                        JSONObject details = json.getJSONArray("weather").getJSONObject(0);
                        JSONObject main = json.getJSONObject("main");
                        JSONObject wind = json.getJSONObject("wind");
                        JSONObject clouds = json.getJSONObject("clouds");
                        citySelection.setText(json.getString("name").toUpperCase(Locale.US) + ", " + json.getJSONObject("sys").getString("country"));
                        weatherCondition.setText(details.getString("main").toUpperCase(Locale.US));
                        temperature.setText("Temperature: " + main.getString("temp") + "°F");
                        pressure.setText("Pressure: " + main.getString("pressure") + "hPa");
                        windSpeed.setText("Wind Speed: " + wind.getString("speed") + "mph");
                        cloudCover.setText("Cloud Cover: " + clouds.getString("all") + "%");
                    }
                } catch (JSONException e) {
                    Toast.makeText(getApplicationContext(), "Weather For Your City", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }